toyA_hello <- function() paste("toyA 0.2 says:", toyB::toyB_hello())

toyA_hello <- function() paste("toyA 0.1 says:", toyB::toyB_hello())

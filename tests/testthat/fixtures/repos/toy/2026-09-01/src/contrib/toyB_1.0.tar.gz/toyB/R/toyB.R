toyB_hello <- function() "hello from toyB"

toyD_hello <- function() paste("toyD at 2e1f5a9 says:", toyB::toyB_hello())

toyD_hello <- function() paste("toyD at 1d0c4e8 says:", toyB::toyB_hello())
